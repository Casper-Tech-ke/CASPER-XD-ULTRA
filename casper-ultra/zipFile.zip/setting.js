//═════════════════════════════════//

/*
🔗 Alicia System Framework
by XyrooRynzz • 2022 - 2026

>> Source Links:
・WhatsApp : wa.me/6281543496975
・WA Channel : whatsapp.com/channel/0029VaagYHwCnA82hDK7l31D
・Telegram : t.me/XyrooRynzz
*/

//═════════════════════════════════//
//━━━━━━━━━━━━━━━━━━━━━━━━//
// Owner Setting
global.owner = ["6281543496975",]
global.ownername = "XyrooRynzz"
//━━━━━━━━━━━━━━━━━━━━━━━━//
// Bot Setting
global.botname = "Alicia WaBot"
global.botver = "1.0.0"
global.idch = "120363299254074394@newsletter"
global.newsletterName = "X - Informations"
global.typebot = "Case X Plugin"
global.session = "session"
global.thumb = "https://files.catbox.moe/qbcebp.jpg"
global.wagc = "https://chat.whatsapp.com/JotecPIv9DGJDDTJ1wKt3l"
global.welcome = false
global.adminevent = false
//━━━━━━━━━━━━━━━━━━━━━━━━//
// Sticker Marker
global.packname = "Alicia WaBot"
global.author = "© XyrooRynzz"
//━━━━━━━━━━━━━━━━━━━━━━━━//
// Respon Message
global.mess = {
    success: '✅ Done.',
    admin: '🚨 Admin only.',
    botAdmin: '🤖 Make me admin first.',
    OnlyOwner: '👑 Owner only.',
    OnlyGrup: '👥 Group only.',
    private: '📩 Private chat only.',
    wait: '⏳ Processing...',
    error: '⚠️ Error occurred.',
}
//━━━━━━━━━━━━━━━━━━━━━━━━//
// File Update
let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Uodate File 📁 : ${__filename}`)
delete require.cache[file]
require(file)
})