//═════════════════════════════════//

/*
🔗 Alicia System Framework
by XyrooRynzz • 2022 - 2026

>> Source Links:
・WhatsApp : wa.me/6281543496975
・WA Channel : whatsapp.com/channel/0029VaagYHwCnA82hDK7l31D
・Telegram : t.me/XyrooRynzz
*/

//═════════════════════════════════//
 
//━━━━━━━━━━━━━━━━━━━━━━━━//
// Module
require("./setting")
const { downloadContentFromMessage, proto, generateWAMessage, getContentType, prepareWAMessageMedia, generateWAMessageFromContent, GroupSettingChange, jidDecode, WAGroupMetadata, emitGroupParticipantsUpdate, emitGroupUpdate, generateMessageID, jidNormalizedUser, generateForwardMessageContent, WAGroupInviteMessageGroupMetadata, GroupMetadata, Headers, delay, WA_DEFAULT_EPHEMERAL, WADefault, getAggregateVotesInPollMessage, generateWAMessageContent, areJidsSameUser, useMultiFileAuthState, fetchLatestBaileysVersion, makeCacheableSignalKeyStore, makeWaconnet, makeInMemoryStore, MediaType, WAMessageStatus, downloadAndSaveMediaMessage, AuthenticationState, initInMemoryKeyStore, MiscMessageGenerationOptions, useSingleFileAuthState, BufferJSON, WAMessageProto, MessageOptions, WAFlag, WANode, WAMetric, ChatModification, MessageTypeProto, WALocationMessage, ReconnectMode, WAContextInfo, ProxyAgent, waChatKey, MimetypeMap, MediaPathMap, WAContactMessage, WAContactsArrayMessage, WATextMessage, WAMessageContent, WAMessage, BaileysError, WA_MESSAGE_STATUS_TYPE, MediaConnInfo, URL_REGEX, WAUrlInfo, WAMediaUpload, mentionedJid, processTime, Browser, MessageType,
Presence, WA_MESSAGE_STUB_TYPES, Mimetype, relayWAMessage, Browsers, DisconnectReason, WAconnet, getStream, WAProto, isBaileys, AnyMessageContent, templateMessage, InteractiveMessage, Header } = require("@whiskeysockets/baileys")
const os = require('os')
const fs = require('fs')
const fg = require('api-dylux')
const fetch = require('node-fetch');
const util = require('util')
const axios = require('axios')
const { exec, execSync } = require("child_process")
const chalk = require('chalk')
const nou = require('node-os-utils')
const moment = require('moment-timezone');
const path = require ('path');
const didyoumean = require('didyoumean');
const similarity = require('similarity');
const speed = require('performance-now')
const { Sticker } = require('wa-sticker-formatter');
const { igdl } = require("btch-downloader");
const yts = require ('yt-search');
//> Scrape <//
const jktNews = require('./library/scrape/jktNews');
const otakuDesu = require('./library/scrape/otakudesu');
const Kusonime = require('./library/scrape/kusonime');
const { quote } = require('./library/scrape/quote.js');
const { fdown } = require('./library/scrape/facebook.js')

const {
	komiku,
	detail
} = require('./library/scrape/komiku');

const {
	wikimedia
} = require('./library/scrape/wikimedia');

const { 
	CatBox, 
	fileIO, 
	pomfCDN, 
	uploadFile
} = require('./library/scrape/uploader');

module.exports = async (X, m) => {
try {
const from = m.key.remoteJid
var body = (m.mtype === 'interactiveResponseMessage') ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype == 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ""
//━━━━━━━━━━━━━━━━━━━━━━━━//
// library
const { smsg, fetchJson, getBuffer, fetchBuffer, getGroupAdmins, TelegraPh, isUrl, hitungmundur, sleep, clockString, checkBandwidth, runtime, tanggal, getRandom } = require('./library/lib/myfunc')

//━━━━━━━━━━━━━━━━━━━━━━━━//
// Main Setting (Admin And Prefix ) 
const budy = (typeof m.text === 'string') ? m.text : '';
const prefixRegex = /^[°zZ#$@*+,.?=''():√%!¢£¥€π¤ΠΦ_&><`™©®Δ^βα~¦|/\\©^]/;
const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : '.';
const isCmd = body.startsWith(prefix);
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '';
const args = body.trim().split(/ +/).slice(1)
const text = q = args.join(" ")
const sender = m.key.fromMe ? (X.user.id.split(':')[0]+'@s.whatsapp.net' || X.user.id) : (m.key.participant || m.key.remoteJid)
const botNumber = await X.decodeJid(X.user.id)
const senderNumber = sender.split('@')[0]
const XyrooRynzz = (m && m.sender && [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)) || false;
const pushname = m.pushName || `${senderNumber}`
const isBot = botNumber.includes(senderNumber)
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const groupMetadata = m.isGroup ? await X.groupMetadata(from).catch(e => {}) : ''
const groupName = m.isGroup ? groupMetadata.subject : ''
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
//━━━━━━━━━━━━━━━━━━━━━━━━//
// Setting Console
if (m.message) {
console.log(chalk.black(chalk.bgWhite('[ New Message ]')), chalk.black(chalk.bgGreen(new Date)), chalk.black(chalk.bgBlue(budy || m.mtype)) + '\n' + chalk.magenta('» Dari'), chalk.green(pushname), chalk.yellow(m.sender) + '\n' + chalk.blueBright('» Di'), chalk.green(m.isGroup ? pushname : 'Private Chat', from))
}
//━━━━━━━━━━━━━━━━━━━━━━━━//
// Reply / Reply Message
const reply = (teks) => { 
X.sendMessage(from, { text: teks, contextInfo: { 
"externalAdReply": { 
"showAdAttribution": true, 
"title": "XyrooRynzz", 
"containsAutoReply": true, 
"mediaType": 1, 
"thumbnail": fakethmb, 
"mediaUrl": "https://t.me/XyrooRynzz", 
"sourceUrl": "https://t.me/XyrooRynzz" }}}, { quoted: m }) }

const reply2 = (teks) => {
X.sendMessage(from, { text : teks }, { quoted : m })
}
//━━━━━━━━━━━━━━━━━━━━━━━━//
// Function Area
try {
ppuser = await X.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}
ppnyauser = await getBuffer(ppuser)

const reSize = async(buffer, ukur1, ukur2) => {
   return new Promise(async(resolve, reject) => {
      let jimp = require('jimp')
      var baper = await jimp.read(buffer);
      var ab = await baper.resize(ukur1, ukur2).getBufferAsync(jimp.MIME_JPEG)
      resolve(ab)
   })
}
    const fakethmb = await reSize(ppuser, 300, 300)
    // function resize
    let jimp = require("jimp")
const resize = async (image, width, height) => {
    const read = await jimp.read(image);
    const data = await read.resize(width, height).getBufferAsync(jimp.MIME_JPEG);
    return data;
};
//━━━━━━━━━━━━━━━━━━━━━━━━//
// Leaderboard Games
const leaderboardPath = './database/leaderboard.json';

// Load leaderboard
function loadLeaderboard() {
  if (!fs.existsSync(leaderboardPath)) return {};
  return JSON.parse(fs.readFileSync(leaderboardPath));
}

// Save leaderboard
function saveLeaderboard(data) {
  fs.writeFileSync(leaderboardPath, JSON.stringify(data, null, 2));
}

if (
  global.tebakGame &&
  global.tebakGame[m.sender] &&
  m.quoted &&
  m.quoted.text &&
  m.quoted.text.includes(global.tebakGame[m.sender].soal)
) {
  const game = global.tebakGame[m.sender];
  const jawaban = game.jawaban;
  const petunjuk = game.petunjuk || 'Petunjuk tidak tersedia';
  const teksUser = m.body?.toLowerCase();

  if (teksUser === 'nyerah') {
    clearTimeout(game.timeout);
    delete global.tebakGame[m.sender];
    return reply(`😔 Kamu menyerah!\nJawaban yang benar:\n✅ *${jawaban}*`);
  }

  const benar = Array.isArray(jawaban)
    ? jawaban.some(jw => jw.toLowerCase() === teksUser)
    : teksUser === jawaban.toLowerCase();

  if (teksUser && benar) {
    let leaderboard = loadLeaderboard();
    leaderboard[m.sender] = (leaderboard[m.sender] || 0) + 1;
    saveLeaderboard(leaderboard);

    clearTimeout(game.timeout);
    delete global.tebakGame[m.sender];
    return reply('✅ Benar! Jawabanmu tepat!\n\nKetik .tebakld untuk melihat leaderboard.');
  } else if (teksUser) {
    return reply(`❌ Salah. Coba lagi!\n💡 Petunjuk: ${petunjuk}\n\nKetik *nyerah* jika ingin menyerah.`);
  }
}
//━━━━━━━━━━━━━━━━━━━━━━━━//
// autoshalat
X.autoshalat = X.autoshalat ? X.autoshalat : {}
	let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? X.user.id : m.sender
	let id = m.chat 
    if(id in X.autoshalat) {
    return false
    }
    let jadwalSholat = {
    shubuh: '04:29',
    terbit: '05:44',
    dhuha: '06:02',
    dzuhur: '12:02',
    ashar: '15:15',
    magrib: '18:11',
    isya: '19:01',
    }
    const datek = new Date((new Date).toLocaleString("en-US", {
    timeZone: "Asia/Jakarta"  
    }));
    const hours = datek.getHours();
    const minutes = datek.getMinutes();
    const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`
    for(let [sholat, waktu] of Object.entries(jadwalSholat)) {
    if(timeNow === waktu) {
    let caption = `Hai kak ${pushname},\nWaktu *${sholat}* telah tiba, ambilah air wudhu dan segeralah shalat🙂.\n\n*${waktu}*\n_untuk wilayah Sumatra dan sekitarnya._`
    X.autoshalat[id] = [
    reply(caption),
    setTimeout(async () => {
    delete X.autoshalat[m.chat]
    }, 57000)
    ]
    }
    }
//━━━━━━━━━━━━━━━━━━━━━━━━//
// Similarity
function getCaseNames() {
  try {
    const data = fs.readFileSync('./client.js', 'utf8');
    const casePattern = /case\s+'([^']+)'/g;
    const matches = data.match(casePattern);

    if (matches) {
      return matches.map(match => match.replace(/case\s+'([^']+)'/, '$1'));
    } else {
      return [];
    }
  } catch (error) {
    console.error('Terjadi kesalahan:', error);
    throw error;
  }
}

if (prefix && command) {
  const caseNames = getCaseNames();
  let noPrefix = m.text.replace(prefix, '').trim();
  let mean = didyoumean(noPrefix, caseNames);
  let sim = similarity(noPrefix, mean);
  let similarityPercentage = parseInt(sim * 100);

  if (mean && noPrefix.toLowerCase() !== mean.toLowerCase()) {
    const respony = (`Maaf, command yang Anda masukkan salah. Berikut adalah command yang mungkin sesuai:\n\n➠  *${prefix + mean}*\n➠  *Kemiripan:* ${similarityPercentage}%`);
    reply(respony);
  }
}
//━━━━━━━━━━━━━━━━━━━━━━━━//
let totalfitur = () =>{
var mytext = fs.readFileSync("./client.js").toString()
var numUpper = (mytext.match(/case '/g) || []).length;
return numUpper
        }
//━━━━━━━━━━━━━━━━━━━━━━━━//
// Function Waktu
function getFormattedDate() {
  var currentDate = new Date();
  var day = currentDate.getDate();
  var month = currentDate.getMonth() + 1;
  var year = currentDate.getFullYear();
  var hours = currentDate.getHours();
  var minutes = currentDate.getMinutes();
  var seconds = currentDate.getSeconds();
}

let d = new Date(new Date + 3600000)
let locale = 'id'
let week = d.toLocaleDateString(locale, { weekday: 'long' })
let date = d.toLocaleDateString(locale, {
  day: 'numeric',
  month: 'long',
  year: 'numeric'
})
const hariini = d.toLocaleDateString('id', { day: 'numeric', month: 'long', year: 'numeric' })

function msToTime(duration) {
var milliseconds = parseInt((duration % 1000) / 100),
seconds = Math.floor((duration / 1000) % 60),
minutes = Math.floor((duration / (1000 * 60)) % 60),
hours = Math.floor((duration / (1000 * 60 * 60)) % 24)

hours = (hours < 10) ? "0" + hours : hours
minutes = (minutes < 10) ? "0" + minutes : minutes
seconds = (seconds < 10) ? "0" + seconds : seconds
return hours + " jam " + minutes + " menit " + seconds + " detik"
}

function msToDate(ms) {
		temp = ms
		days = Math.floor(ms / (24*60*60*1000));
		daysms = ms % (24*60*60*1000);
		hours = Math.floor((daysms)/(60*60*1000));
		hoursms = ms % (60*60*1000);
		minutes = Math.floor((hoursms)/(60*1000));
		minutesms = ms % (60*1000);
		sec = Math.floor((minutesms)/(1000));
		return days+" Hari "+hours+" Jam "+ minutes + " Menit";
  }
//━━━━━━━━━━━━━━━━━━━━━━━━//
// Ucapan Waktu
const timee = moment().tz('Asia/Jakarta').format('HH:mm:ss')
if(timee < "23:59:00"){
var waktuucapan = 'Selamat Malam 🌃'
}
if(timee < "19:00:00"){
var waktuucapan = 'Selamat Petang 🌆'
}
if(timee < "18:00:00"){
var waktuucapan = 'Selamat Sore 🌅'
}
if(timee < "15:00:00"){
var waktuucapan = 'Selamat Siang 🏙'
}
if(timee < "10:00:00"){
var waktuucapan = 'Selamat Pagi 🌄'
}
if(timee < "05:00:00"){
var waktuucapan = 'Selamat Subuh 🌉'
}
if(timee < "03:00:00"){
var waktuucapan = 'Tengah Malam 🌌'
}
//━━━━━━━━━━━━━━━━━━━━━━━━//
// Plugin Connector
const loadPlugins = (directory) => {
    let plugins = []
    const folders = fs.readdirSync(directory)
    folders.forEach(folder => {
        const folderPath = path.join(directory, folder)
        if (fs.lstatSync(folderPath).isDirectory()) {
            const files = fs.readdirSync(folderPath)
            files.forEach(file => {
                const filePath = path.join(folderPath, file)
                if (filePath.endsWith(".js")) {
                    try {
                        delete require.cache[require.resolve(filePath)]
                        const plugin = require(filePath)
                        plugin.filePath = filePath
                        plugins.push(plugin)
                    } catch (error) {
                        console.error(`Error loading plugin at ${filePath}:`, error)
                    }
                }
            })
        }
    })
    return plugins
}
const plugins = loadPlugins(path.resolve(__dirname, "./plugin"))
const context = { 
    args, 
    X, 
    reply,
    m, 
    body,   
    prefix,
    command,
    isUrl,
    q,
    text,
    quoted,
    require,
    smsg,
    sleep,
    clockString,
    msToDate,
    runtime,
    fetchJson,
    getBuffer,
    delay,
    getRandom
     }
let handled = false
for (const plugin of plugins) {
    if (plugin.command.includes(command)) {
        try {
            await plugin.operate(context)
            handled = true
        } catch (error) {
            console.error(`Error executing plugin ${plugin.filePath}:`, error)
        }
        break
    }
}
// Batas Plugins
//━━━━━━━━━━━━━━━━━━━━━━━━//
//━━━━━━━━━━━━━━━━━━━━━━━━//
// tag owner reaction
if (m.isGroup) {
    if (body.includes(`@${owner}`)) {
        reaction(m.chat, "❌")
    }
 }
// tes bot no prefix
if ((budy.match) && ["bot",].includes(budy) && !isCmd) {
reply(`bot online ✅`)
}	

//━━━━━━━━━━━━━━━━━━━━━━━━//
// jangan di apa apain
switch(command) {
// awas error
//━━━━━━━━━━━━━━━━━━━━━━━━//
// system menu
case 'menu': {
// menu list terpisah
const aiMenu = require('./library/menulist/aimenu');
const toolsMenu = require('./library/menulist/toolsmenu');
const groupMenu = require('./library/menulist/groupmenu');
const ownerMenu = require('./library/menulist/ownermenu');
const searchMenu = require('./library/menulist/searchmenu');
const gameMenu = require('./library/menulist/gamemenu');
const stickerMenu = require('./library/menulist/stickermenu');
const otherMenu = require('./library/menulist/othermenu');
const downloaderMenu = require('./library/menulist/downloadermenu');

  let subcmd = args[0] ? args[0].toLowerCase() : '';

  let infoBot = `
👋 Hai, ${pushname}
I am Alicia WaBot who can help you search, play, or download. I am Alicia WaBot who can help you search, play, or download. I can also be a chat companion, confidant.

╭─ ⌬ Bot Info
│ • name   : ${botname}
│ • owner  : ${ownername}
│ • version  : ${botver}
│ • type   : ${typebot}
│ • command  : ${totalfitur()}
╰─────────────

${waktuucapan}

`.trim();

  let menu = '';

  if (subcmd === 'ai') menu = aiMenu;
  else if (subcmd === 'tools') menu = toolsMenu;
  else if (subcmd === 'group') menu = groupMenu;
  else if (subcmd === 'owner') menu = ownerMenu;
  else if (subcmd === 'search') menu = searchMenu;
  else if (subcmd === 'games') menu = gameMenu;
  else if (subcmd === 'sticker') menu = stickerMenu;  
  else if (subcmd === 'other') menu = otherMenu;    
  else if (subcmd === 'downloader') menu = downloaderMenu;    
  else if (subcmd === 'all') {
    menu = [
      otherMenu,
      downloaderMenu,
      stickerMenu,
      ownerMenu,
      groupMenu,
      toolsMenu,
      gameMenu,
      searchMenu,
      aiMenu
    ].join('\n');
  } else {
    menu = `

📂 *Menu List*
⤷ .menu ai
⤷ .menu all
⤷ .menu other
⤷ .menu tools
⤷ .menu group
⤷ .menu owner
⤷ .menu search
⤷ .menu games
⤷ .menu sticker
⤷ .menu downloader

Ketik: *.menu [kategori]*
`.trim();
  }

  let fullMenu = `${infoBot}\n${menu}`;

  await X.sendMessage(
    m.chat,
    {
      text: fullMenu,
      contextInfo: {
        forwardingScore: 999,
        isForwarded: true,
        mentionedJid: [sender],
        externalAdReply: {
          title: "Alicia WaBot",
          body: "XyrooRynzz",
          thumbnail: fs.readFileSync('./media/thumb.png'),
          sourceUrl: wagc,
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    },
    { quoted: m }
  );
}
break;

//━━━━━━━━━━━━━━━━━━━━━━━━//
// Download Features
case 'mfdl':
case 'mediafire': {
 if (!text) return reply('sertakan link mediafire')
// wait message
reply(global.mess.wait)
  try {
    const api = await fetchJson(`https://api.vreden.web.id/api/mediafiredl?url=${encodeURIComponent(text)}`)
    if (!api.status || !api.result || !api.result[0]) return reply('Gagal mengambil data dari API.')

    const data = api.result[0]
    const fileNama = decodeURIComponent(data.nama || 'file.zip')
    const extension = fileNama.split('.').pop().toLowerCase()

    const res = await axios.get(data.link, { responseType: 'arraybuffer' })
    const media = Buffer.from(res.data)

    let mimetype = ''
    if (extension === 'mp4') mimetype = 'video/mp4'
    else if (extension === 'mp3') mimetype = 'audio/mp3'
    else mimetype = `application/${extension}`

    await X.sendMessage(m.chat, {
      document: media,
      fileName: fileNama,
      mimetype: mimetype
    }, { quoted: m })
  } catch (err) {
    console.error(err)
    reply('Terjadi kesalahan saat mendownload: ' + err.message)
  }
}
break
case 'ig':
case 'instagram': {
    if (!text) return reply("Masukkan Linknya ?");
// wait message
reply(global.mess.wait)
    const mediaUrl = await igdl(text);
    const url_media = mediaUrl[0].url;
    try {
        const response = await axios.head(url_media); 
        const contentType = response.headers['content-type']; // Mendapatkan tipe konten dari header
        if (contentType.startsWith('image/')) {
            await X.sendMessage(m.chat, { image: { url: url_media}, caption: 'donee' }, { quoted: m });
            return
        } else {
            await X.sendMessage(m.chat, { video: { url: url_media}, caption: 'donee' }, { quoted: m });
            return 
        }
    } catch(e) {
       reply('eror')
    }
}
break

case 'tt': 
case 'tiktok': {
if (!text) return reply(`Contoh : ${prefix + command} linknya`)
// wait message
reply(global.mess.wait)
let data = await fg.tiktok(text)
let json = data.result
let caption = `[ TIKTOK - DOWNLOAD ]\n\n`
caption += `◦ *Id* : ${json.id}\n`
caption += `◦ *Username* : ${json.author.nickname}\n`
caption += `◦ *Title* : ${(json.title)}\n`
caption += `◦ *Like* : ${(json.digg_count)}\n`
caption += `◦ *Comments* : ${(json.comment_count)}\n`
caption += `◦ *Share* : ${(json.share_count)}\n`
caption += `◦ *Play* : ${(json.play_count)}\n`
caption += `◦ *Created* : ${json.create_time}\n`
caption += `◦ *Size* : ${json.size}\n`
caption += `◦ *Duration* : ${json.duration}`
if (json.images) {
json.images.forEach(async (k) => {
await X.sendMessage(m.chat, { image: { url: k }}, { quoted: m });
})
} else {
X.sendMessage(m.chat, { video: { url: json.play }, mimetype: 'video/mp4', caption: caption }, { quoted: m })
setTimeout(() => {
X.sendMessage(m.chat, { audio: { url: json.music }, mimetype: 'audio/mpeg' }, { quoted: m })
}, 3000)
}
}
break

case 'fb':
case 'fbdl':
case 'facebook' : {
if (!text) return reply('url facebook?')
// wait message
reply(global.mess.wait)
    try {
      let res = await fdown.download(text);
      if (res && res.length > 0) {
        let videoData = res[0]; 
        let videoUrl = videoData.hdQualityLink || videoData.normalQualityLink; 
        if (videoUrl) {
          let caption = `*Title:* ${videoData.title}\n*Description:* ${videoData.description}\n*Duration:* ${videoData.duration}`;
          await X.sendMessage(m.chat, { 
            video: { url: videoUrl }, 
            caption: caption, 
            mimetype: 'video/mp4'
          }, { quoted: m });
        }
      } else {
        return reply(mess.error)
      }
    } catch (e) {
      console.log(e);
      reply('eror')
    }
  }
break
case 'putar':
case 'lagu':
case 'music':
case 'ytplay': 
case 'play': {
    if (!text) return reply('lagu apa yg ingin dicari');
// wait message
reply(global.mess.wait)
    try {
        let search = await yts(text);
        let firstVideo = search.all[0];
        let response = await ddownr.download(firstVideo.url, 'mp3')
        let hasil = response.downloadUrl
        await X.sendMessage(m.chat, {
            audio: {
                url: hasil
            },
            mimetype: 'audio/mp4',
            contextInfo: {
                externalAdreply: {
                    showAdAttribution: true,
                    title: firstVideo.title || 'Untitled',
                    body: `Alicia WaBot`,
                    sourceUrl: firstVideo.url,
                    thumbnailUrl: firstVideo.thumbnail || 'https://example.com/default_thumbnail.jpg',
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: m });
    } catch (e) {
      console.log(e)
        await X.sendMessage(m.chat, { react: { text: '🚫', key: m.key } });
        try {
            let search = await yts(text);
            let firstVideo = search.all[0];
            let memek = await fetchJson(`${global.beta}/api/download/ytmp3?url=${firstVideo.url}&apikey=${global.botz}`);
            let hasil = memek.result;

            await X.sendMessage(m.chat, {
                audio: {
                    url: hasil.mp3
                },
                mimetype: 'audio/mp4',
                contextInfo: {
                    externalAdreply: {
                        showAdAttribution: true,
                        title: firstVideo.title || 'Untitled',
                        body: `Alicia WaBot`,
                        sourceUrl: firstVideo.url,
                        thumbnailUrl: firstVideo.thumbnail || 'https://example.com/default_thumbnail.jpg',
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                }
            }, { quoted: m });
        } catch (e) {
            console.log(e);
            let search = await yts(text);
            let firstVideo = search.all[0];
            let Xyroo = await fetchJson(`https://api.agatz.xyz/api/ytmp3?url=${firstVideo.url}`);

            await X.sendMessage(m.chat, {
                audio: {
                    url: Xyroo.data
                },
                mimetype: 'audio/mp4',
                contextInfo: {
                    externalAdreply: {
                        showAdAttribution: true,
                        title: firstVideo.title || 'Untitled',
                        body: `Alicia WaBot`,
                        sourceUrl: firstVideo.url,
                        thumbnailUrl: firstVideo.thumbnail || 'https://example.com/default_thumbnail.jpg',
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                }
            }, { quoted: m });
        }
    }
}
break;
//━━━━━━━━━━━━━━━━━━━━━━━━//
// Other Features
case 'owner': case 'botowner':
let namaown = `XyrooRynzz`
var contact = generateWAMessageFromContent(m.chat, proto.Message.fromObject({
"contactMessage": {
"displayName": `${namaown}`,
"vcard": `BEGIN:VCARD\nVERSION:3.0\nN:;;;;\nFN:XyrooRynzz\nitem1.TEL;waid=6281543496975:+6281543496975\nitem1.X-ABLabel:Ponsel\nX-WA-BIZ-DESCRIPTION:${ownername}\nX-WA-BIZ-NAME: ${namaown}\nEND:VCARD`,
}
}), { userJid: m.chat, quoted: m })
X.relayMessage(m.chat, contact.message, { messageId: contact.key.id })
break

case 'sc': {
reply(`ingin script alicia wabot? cek youtube xyroo aja\nyoutube : https://www.youtube.com/@xyroorynzzz\ninfo update script : https://whatsapp.com/channel/0029VaagYHwCnA82hDK7l31D\ncontact developer : https://t.me/XyrooRynzz`)
}
break

case 'infobot':
case 'botinfo': {
// wait message
reply(global.mess.wait)
  const botInfo = `
╭─ ⌬ Bot Info
│ • Name    : ${botname}
│ • Owner   : ${ownername}
│ • Version  : ${botver}
│ • Command : ${totalfitur()}
│ • Runtime  : ${runtime(process.uptime())}\n╰─────────────
`
  reply(botInfo)
}
break
//━━━━━━━━━━━━━━━━━━━━━━━━//
// Sticker Features
case 'bratvid':
case 'bratv':
case 'bratvideo': {
  if (!text) return reply(`Contoh: ${prefix + command} hai bang`)
  if (text.length > 250) return reply(`Karakter terbatas, max 250!`)
// wait message
reply(global.mess.wait)
  const words = text.split(" ")
  const tempDir = path.join(process.cwd(), 'tmp')
  if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir)
  const framePaths = []

  try {
    for (let i = 0; i < words.length; i++) {
      const currentText = words.slice(0, i + 1).join(" ")

      const res = await axios.get(
        `https://brat.caliphdev.com/api/brat?text=${encodeURIComponent(currentText)}`,
        { responseType: "arraybuffer" }
      ).catch((e) => e.response)

      const framePath = path.join(tempDir, `frame${i}.mp4`)
      fs.writeFileSync(framePath, res.data)
      framePaths.push(framePath)
    }

    const fileListPath = path.join(tempDir, "filelist.txt")
    let fileListContent = ""

    for (let i = 0; i < framePaths.length; i++) {
      fileListContent += `file '${framePaths[i]}'\n`
      fileListContent += `duration 0.7\n`
    }

    fileListContent += `file '${framePaths[framePaths.length - 1]}'\n`
    fileListContent += `duration 2\n`

    fs.writeFileSync(fileListPath, fileListContent)
    const outputVideoPath = path.join(tempDir, "output.mp4")
    execSync(
      `ffmpeg -y -f concat -safe 0 -i ${fileListPath} -vf "fps=30" -c:v libx264 -preset ultrafast -pix_fmt yuv420p ${outputVideoPath}`
    )

    await X.sendImageAsSticker(m.chat, outputVideoPath, xy, {
      packname: '',
      author: `${author}`
    })

    framePaths.forEach((frame) => {
      if (fs.existsSync(frame)) fs.unlinkSync(frame)
    })
    if (fs.existsSync(fileListPath)) fs.unlinkSync(fileListPath)
    if (fs.existsSync(outputVideoPath)) fs.unlinkSync(outputVideoPath)
  } catch (err) {
    console.error(err)
    reply('Terjadi kesalahan')
  }
}
break

case 'brat': {
if (!q) return reply(`Masukkan teks\n\nContoh: ${prefix + command} alok hamil`);
// wait message
reply(global.mess.wait)
let rulz = `https://aqul-brat.hf.space/api/brat?text=${encodeURIComponent(q)}`;
try {
const res = await axios.get(rulz, { responseType: 'arraybuffer' });
const buffer = Buffer.from(res.data, 'binary');
await X.sendImageAsSticker(m.chat, buffer, m, { packname: ``, author: `${author}` });
} catch (e) {
console.log(e);
await reply(`Sedang maintenance atau API error`);
    }
}
break

case 'emojimix': {
    if (!text) return reply(`example : 😎+😂 atau 😎|😂`);

    const emojis = text.split(/[\+\|]/);
    if (emojis.length !== 2) return reply('Silakan masukkan dua emoji yang valid, example: 😎+😂 atau 😎|😂');
// wait message
reply(global.mess.wait)
    const text1 = emojis[0].trim();
    const text2 = emojis[1].trim();
 
    let api = `https://fastrestapis.fasturl.cloud/maker/emojimix?emoji1=${text1}&emoji2=${text2}`;
    await X.sendImageAsSticker(m.chat, api, m, { packname: '', author: `${packname}` });
}
break;
case 'qc': {
    let text;

    if (args.length >= 1) {
        text = args.slice(0).join(" ");
    } else if (m.quoted && m.quoted.text) {
        text = m.quoted.text;
    } else {
        return reply("Input teks atau reply teks yang ingin di jadikan quote!");
    }
    if (!text) return reply('masukan text');
    if (text.length > 200) return reply('Maksimal 200 Teks!');
// wait message
reply(global.mess.wait)
    let ppnyauser = await X.profilePictureUrl(m.sender, 'image').catch(_ => 'https://files.catbox.moe/nwvkbt.png');
    const rest = await quote(text, pushname, ppnyauser);
    X.sendImageAsSticker(m.chat, rest.result, m, {
        packname: ``,
        author: `${global.author}`
    });
}
break
case 'sticker':
case 'stiker':
case 's':{
if (!quoted) return reply(`Balas Video/Image Dengan Caption ${prefix + command}`)
// wait message
reply(global.mess.wait)
if (/image/.test(mime)) {
let media = await quoted.download()
let encmedia = await X.sendImageAsSticker(m.chat, media, m, {
packname: global.packname,
author: global.author
})
} else if (/video/.test(mime)) {
if ((quoted.msg || quoted).seconds > 31) return reply('Maksimal 30 detik!')
let media = await quoted.download()
let encmedia = await X.sendVideoAsSticker(m.chat, media, m, {
packname: global.packname,
author: global.author
})
} else {
return reply(`Kirim Gambar/Video Dengan Caption ${prefix + command}\nDurasi Video 1-9 Detik`)
}
}
break
//━━━━━━━━━━━━━━━━━━━━━━━━//
// Developer tools
case 'self': {
if (!XyrooRynzz) return reply(mess.OnlyOwner)
X.public = false
reply('Sukses Change To Self Mode')
}
break

case 'public': {
if (!XyrooRynzz) return reply(mess.OnlyOwner)
X.public = true
reply('Sukses Change To Public Mode')
}
break

case 'restart':
if (!XyrooRynzz) return reply(mess.OnlyOwner)
reply(`Berhasil Di Restart ✅`)
await sleep(3000)
process.exit()
break

case 'addplugin': case 'addplug':{
if (!XyrooRynzz) return  reply(mess.OnlyOwner)
if (!q.includes("|")) return reply(`${command}, *Example :* \n\n*${prefix + command} name|category|content*`)
const [
pluginName,
category, ...pluginContent
] = q.split("|")
const pluginDirPath = path.join(path.resolve(__dirname, './plugin', category))
const pluginFilePath = path.join(pluginDirPath, pluginName + ".js")
if (!q.includes("|") || pluginContent.length === 0 || fs.existsSync(pluginFilePath)) return
if (!fs.existsSync(pluginDirPath)) fs.mkdirSync(pluginDirPath, {
recursive: true
})
fs.writeFileSync(pluginFilePath, pluginContent.join('|'))
await reply(`A new plugin has been created in ${pluginFilePath}.`)
}
break
case 'cgplugin': case 'cgplug':{
if (!XyrooRynzz) return  reply(mess.OnlyOwner)
if (!q.includes("|")) return reply (`${command}, *Example :* *${prefix + command} pluginnya|isi barunya*`)
let [mypler, ...rest] = q.split("|")
let mypenis = rest.join("|")
let pluginsDirect = path.resolve(__dirname, './plugin')
let plugins = loadPlugins(pluginsDirect)
for (const plugin of plugins) {
if (plugin.command.includes(mypler)) {
let filePath = plugin.filePath
fs.writeFileSync(filePath, mypenis)
await reply(`The plugin in ${filePath} has been replaced`)
return
}
}
await reply(`Plugin with command '${mypler}' not found`)
}
break
case 'rmplugin': case 'rmplug':{
if (!XyrooRynzz) return  reply(mess.OnlyOwner)
if (!q) return reply(`*Example :* \n\n*${prefix + command} nama plugin*`)
let pluginsDirect = path.resolve(__dirname, './plugin')
let plugins = loadPlugins(pluginsDirect)
for (const plugin of plugins) {
if (plugin.command.includes(q)) {
let filePath = plugin.filePath
fs.unlinkSync(filePath)
await reply(`The plugin in ${filePath} has been removed.`)
return
}
}
await reply(`Plugin with command '${q}' not found.`)
}
break
case 'getplugin': case 'getplug':{
if (!XyrooRynzz) return  reply(mess.OnlyOwner)
if (!q) return reply(`*Example :* \n\n*${prefix + command} nama plugin`) 
let pluginsDirect = path.resolve(__dirname, './plugin')
let plugin = loadPlugins(pluginsDirect).find(p => p.command.includes(q))
if (!plugin) return reply(`Plugin with command '${q}' not found.`)
await nova.sendMessage(m.chat, {
document: fs.readFileSync(plugin.filePath),
fileName: path.basename(plugin.filePath),
mimetype: '*/*'
}, {
quoted: m
})
await reply(`Successfully retrieved plugin '${q}', plugin has been submitted.`)
}
break

//━━━━━━━━━━━━━━━━━━━━━━━━//
// Group Features

            case 'welcome':
            case 'left':{
               if (!m.isGroup) return reply('Khusus Di Dalam Grub')
if (!isAdmins && !XyrooRynzz) return reply(mess.OnlyOwner)
               if (args.length < 1) return reply('Contoh : Welcome Hidup/Mati')
               if (args[0] === 'hidup') {
                  welcome = true
                  reply(`${command} Sudah Diaktifkan`)
               } else if (args[0] === 'mati') {
                  welcome = false
                  reply(`${command} Sudah Dimatikan`)
               }
            }
            break
            case 'groupevent':{
               if (!m.isGroup) return reply ('Hanya Digrub')
if (!isAdmins && !XyrooRynzz) return reply(mess.OnlyOwner)
               if (args.length < 1) return reply('Hidup / Mati?')
               if (args[0] === 'hidup') {
                  groupevent = true
                  reply(`${command} Sudah Dinyalakan`)
               } else if (args[0] === 'mati') {
                  groupevent = false
                  reply(`${command} Sudah Dimatikan`)
               }
            }
            break
            
            
			case 'add': {
				if (!m.isGroup) return reply(mess.OnlyGrup);
				if (!isAdmins && !XyrooRynzz) return reply(mess.admin);
				if (!isBotAdmins) return reply(mess.botAdmin);
				if (!text && !m.quoted) {
					reply(`_Example :_\n\n ${prefix + command} 62xxx`);
				} else {
					const numbersOnly = text ? text.replace(/\D/g, '') + '@s.whatsapp.net' : m.quoted?.sender;
					try {
						await X.groupParticipantsUpdate(m.chat, [numbersOnly], 'add')
							.then(async (res) => {
								for (let i of res) {
									let invv = await X.groupInviteCode(m.chat);
									if (i.status == 408) return reply(`_[ Error ]_ User Baru Saja Keluar Dari Grub`);
									if (i.status == 401) return reply(`_] Error ]_ Bit Diblokir User`);
									if (i.status == 409) return reply(`_[ Report ]_ User Telah Ada Digrub`);
									if (i.status == 500) return reply(`_[ Invalid ]_ Grub Telah Penuh`);
									if (i.status == 403) {
										await X.sendMessage(m.chat, { 
											text: `@${numbersOnly.split('@')[0]} Target Tidak Bisa Ditambahkan Karna Akun Di Private, Akan Mengirimkan Undangan Ke Private Chat`, 
											mentions: [numbersOnly] 
										}, { quoted: m });
										await X.sendMessage(`${numbersOnly ? numbersOnly : creator}`, { 
											text: `${'https://chat.whatsapp.com/' + invv}\n━━━━━━━━━━━━━━━━━━━━━\n\nAdmin: wa.me/${m.sender}\n Telah Mengundang Kamu Ke Grub Ini`, 
											detectLink: true, 
											mentions: [numbersOnly] 
										}, { quoted: floc2 }).catch((err) => reply('Gagal kirim undangan! 😔'));
									} else {
										reply(mess.succes);
									}
								}
							});
					} catch (e) {
						reply('Gagal nambahin usernya nih, ada yang salah! 😢');
					}
				}
			}
			break;

			case 'kick': {
				if (!m.isGroup) return reply(mess.OnlyGrup);
				if (!XyrooRynzz && !isAdmins) return reply(mess.admin);
				if (!isBotAdmins) return reply(mess.botAdmin);
				if (!m.quoted && !m.mentionedJid[0] && isNaN(parseInt(args[0]))) {
					return reply(`*Example :* ${prefix + command} target`);
				}
				let users = m.mentionedJid[0] 
				? m.mentionedJid[0] 
				: m.quoted 
				? m.quoted.sender 
				: text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
				if (owner.includes(users.replace('@s.whatsapp.net', ''))) {
					return reply('My Owner, Cant Kick Them');
				}
				try {
					await X.groupParticipantsUpdate(m.chat, [users], 'remove');
					reply(mess.succes);
				} catch (err) {
					console.error(err);
					reply(mess.error);
				}
			};
			break;

			case 'promote': {
				if (!m.isGroup) return reply(mess.OnlyGrup)
				if (!XyrooRynzz && !isAdmins) return reply(mess.admin)
				if (!isBotAdmins) return reply(mess.botAdmin)
				if (!m.quoted && !m.mentionedJid[0] && isNaN(parseInt(args[0]))) return reply('*Example :* ${prefix + command} target');
				let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
				if (!m.mentionedJid[0] && !m.quoted && !text) return reply(`*Example :* ${prefix + command} target`)
				await X.groupParticipantsUpdate(m.chat, [users], 'promote').then((res) => reply(mess.succes)).catch((err) => reply(mess.error))
			}
			break

			case 'demote': {
				if (!m.isGroup) return reply(mess.OnlyGrup)
				if (!XyrooRynzz && !isAdmins) return reply(mess.admin)
				if (!isBotAdmins) return reply(mess.botAdmin)
				if (!m.quoted && !m.mentionedJid[0] && isNaN(parseInt(args[0]))) return reply(`*Example :* ${prefix + command} target`)
				let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
				if (!m.mentionedJid[0] && !m.quoted && !text) return reply(`*Example :* ${prefix + command} target`)
				await X.groupParticipantsUpdate(m.chat, [users], 'demote').then((res) => reply(mess.succes)).catch((err) => reply(mess.error))
			}
			break

			case 'revoke':{
				if (!m.isGroup) return reply(mess.OnlyGrup);
				if (!isAdmins && !XyrooRynzz) return reply(mess.admin);
				if (!isBotAdmins) return reply(mess.botAdmin);
				await X.groupRevokeInvite(m.chat)
					.then(res => {
						reply(mess.succes)
					}).catch(() => reply(mess.error))
				}
				break
				
//━━━━━━━━━━━━━━━━━━━━━━━━//				
// search features
			case 'wikimedia': {
				if (!text) return reply(`*Example :*\n\n${prefix + command} Query`);
				 // wait message
                  reply(global.mess.wait)
				try {
					const results = await wikimedia(text);
					if (results.length === 0) return reply(`⚠️ Mora gak nemu gambar di Wikimedia dengan kata kunci "${text}", Kak! 🥲`);
					let result = results.map(img => `🖼️ *${img.title || 'Tanpa Judul'}*\n🔗 ${img.source}`).join('\n\n');
					reply(`🌐 *Hasil Pencarian Wikimedia untuk*: ${text}\n\n${result}`);
				} catch (err) {
					console.error(err);
					reply(`❌ Ada masalah waktu ambil gambar dari Wikimedia, Kak! Coba lagi nanti ya 🥺`);
				}
			}
			break;

			case 'mangainfo': {
				const mangaName = args.join(' ');
				if (!mangaName) return reply(`*Example :*\n\n${prefix + command} Anime`);
				 // wait message
                  reply(global.mess.wait)				
				try {
					const mangaList = await komiku("manga", mangaName);
					if (mangaList.length === 0) {
						return reply('_[ Invalid ]_ Not Found !!');
					}
					let captionText = `📚 *Hasil Pencarian Manga - ${mangaName}* 📚\n\n`;
					mangaList.slice(0, 5).forEach((manga, index) => {
						captionText += `📖 *${index + 1}. ${manga.title}*\n`;
						captionText += `🗂️ *Genre*: ${manga.genre}\n`;
						captionText += `🔗 *Url*: ${manga.url}\n`;
						captionText += `📖 *Deskripsi*: ${manga.description}\n\n`;
					});
					await reply(captionText);
				} catch (error) {
					console.error("Report Error :", error);
					reply(mess.error);
				}
				break;
			}

			case 'mangadetail': {
				const url = args[0];
				if (!url) return reply(`*Example :*\n\n${prefix + command} URL`);
				 // wait message
                  reply(global.mess.wait)				
				try {
					const mangaDetail = await detail(url);
					let captionText = `📚 *Detail Manga* 📚\n\n`;
					captionText += `📖 *Judul*: ${mangaDetail.title}\n`;
					captionText += `🗂️ *Genre*: ${mangaDetail.genres.join(', ')}\n`;
					captionText += `📖 *Deskripsi*: ${mangaDetail.description}\n`;
					captionText += `📅 *Chapter Awal*: ${mangaDetail.awalChapter}\n`;
					captionText += `📅 *Chapter Terbaru*: ${mangaDetail.newChapter}\n`;
					X.sendMessage(m.chat, {
						image: { url: mangaDetail.coverImage },
						caption: captionText
					}, {
						quoted: m
					})
				} catch (error) {
					console.error("Report Error :", error);
					reply(mess.error);
				}
				break;
			}

			case 'jkt48news': {
				const lang = args[0] || "id";
				 // wait message
                  reply(global.mess.wait)
				try {
					const news = await jktNews(lang);
					if (news.length === 0) {
						return reply('_[ Report ]_ No News Find');
					}
					let captionText = `🎤 *Berita Terbaru JKT48* 🎤\n\n`;
					news.slice(0, 5).forEach((item, index) => {
						captionText += `📰 *${index + 1}. ${item.title}*\n`;
						captionText += `📅 *Tanggal*: ${item.date}\n`;
						captionText += `🔗 *Link*: ${item.link}\n\n`;
					});
					await reply(captionText);
				} catch (error) {
					console.error("Report Error :", error);
					reply(mess.error);
				}
				break;
			}

			case 'otakudesu':{
				let data = await otakuDesu.ongoing();
				let captionText = `「 *JADWAL ANIME* 」\n\n`
				for (let i of data) {
					captionText += `*💬 Judul*: ${i.title}\n`
					captionText += `*📺 Eps*: ${i.episode}\n`
					captionText += `*🔗 URL*: ${i.link}\n\n`
				}
				X.sendMessage(m.chat, {
					text: captionText,
					contextInfo: {
						mentionedJid: [m.sender],
						forwardingScore: 999999, 
						isForwarded: true, 
						forwardedNewsletterMessageInfo: {
							newsletterName: newsletterName,
							newsletterJid: idch,
						},
						externalAdReply: {
							showAdAttribution: true,
							title: 'Ini Update Anime Terbaru!',
							mediaType: 1,
							previewType: 1,
							body: 'Halo 👋',
							thumbnailUrl: thumb,
							renderLargerThumbnail: false,
							mediaUrl: wagc,
							sourceUrl: wagc
						}
					}
				}, {
					quoted: m
				})
			}
			break;

			case 'kusonimeinfo':
			case 'animeinfo': {
				try {
					const animeList = await Kusonime.info();
					if (animeList.length === 0) {
						return reply('_[ Invalid ⚠️ ]_ Tidak ada data anime terbaru yang ditemukan saat ini.');
					}
				 // wait message
                  reply(global.mess.wait)
					let captionText = `🎌 *Anime Terbaru dari Kusonime* 🎌\n\n`;
					animeList.slice(0, 5).forEach((anime, index) => {
						captionText += `📺 *${index + 1}. ${anime.title}*\n`;
						captionText += `🔗 *URL*: ${anime.url}\n`;
						captionText += `🗂️ *Genre*: ${anime.genres.join(', ')}\n`;
						captionText += `📅 *Rilis*: ${anime.releaseTime}\n\n`;
					});
					await reply(captionText);
				} catch (error) {
					console.error("Report Error :", error);
					reply(mess.error);
				};
			}
			break

			case 'kusonimesearch':
			case 'animesearch': {
				if (!text) return reply(`*Example :*\n\n${prefix + command} Anime`);
				 // wait message
                  reply(global.mess.wait)
				try {
					const searchResults = await Kusonime.search(text);
					if (typeof searchResults === 'string') {
						return reply(`⚠️ ${searchResults}`);
					}
					let captionText = `🔍 *Hasil Pencarian untuk*: ${text}\n\n`;
					searchResults.slice(0, 5).forEach((anime, index) => {
						captionText += `📺 *${index + 1}. ${anime.title}*\n`;
						captionText += `🔗 *URL*: ${anime.url}\n`;
						captionText += `🗂️ *Genre*: ${anime.genres.join(', ')}\n`;
						captionText += `📅 *Rilis*: ${anime.releaseTime}\n\n`;
					});
					await reply(captionText);
				} catch (error) {
					console.error("Report Error :", error);
					reply(mess.error);
				}
			}
			break;

			case 'infogempa':
			case 'infobmkg':
			case 'gempa':
			case 'bmkg': {
				 // wait message
                  reply(global.mess.wait)
				try {
					let result = await gempa();
					let gempaData = result.data;
					let captionText = `「 *INFO GEMPA* 」\n\n`;
					captionText += `*🌍 Sumber*: ${result.source}\n`;
					captionText += `*📊 Magnitudo*: ${gempaData.magnitude.trim()}\n`;
					captionText += `*📏 Kedalaman*: ${gempaData.kedalaman.trim()}\n`;
					captionText += `*🗺️ Lintang & Bujur*: ${gempaData.lintang_bujur.trim()}\n`;
					captionText += `*🕒 Waktu*: ${gempaData.waktu.trim()}\n`;
					captionText += `*📍 Wilayah*: ${gempaData.wilayah.trim() || 'Tidak ada data'}\n`;
					captionText += `*😱 Dirasakan*: ${gempaData.dirasakan.trim() || 'Tidak ada data'}\n\n`;
					captionText += `Tetap waspada dan ikuti arahan dari pihak berwenang!`;
					if (gempaData.imagemap) {
						X.sendMessage(m.chat, {
							image: { url: gempaData.imagemap.startsWith('http') ? gempaData.imagemap : `https://www.bmkg.go.id${gempaData.imagemap}` },
							caption: captionText,
							contextInfo: {
								mentionedJid: [m.sender],
								forwardingScore: 999999, 
								isForwarded: true, 
								forwardedNewsletterMessageInfo: {
									newsletterName: saluranName,
									newsletterJid: saluran,
								},
								externalAdReply: {
									showAdAttribution: true,
									title: 'Informasi Gempa Terkini!',
									mediaType: 1,
									previewType: 1,
									body: 'Be careful',
									thumbnailUrl: imageUrl,
									renderLargerThumbnail: false,
									mediaUrl: 'https://www.bmkg.go.id',
									sourceUrl: 'https://www.bmkg.go.id'
								}
							}
						}, {
							quoted: m
						});
					} else {
						X.sendMessage(m.chat, {
							text: captionText,
							contextInfo: {
								mentionedJid: [m.sender],
								forwardingScore: 999999, 
								isForwarded: true, 
								forwardedNewsletterMessageInfo: {
									newsletterName: saluranName,
									newsletterJid: saluran,
								},
								externalAdReply: {
									showAdAttribution: true,
									title: 'Informasi Gempa Terkini!',
									mediaType: 1,
									previewType: 1,
									body: 'Be careful',
									thumbnailUrl: imageUrl,
									renderLargerThumbnail: false,
									mediaUrl: 'https://www.bmkg.go.id',
									sourceUrl: 'https://www.bmkg.go.id'
								}
							}
						}, {
							quoted: m
						});
					}
				} catch (error) {
					console.error("Report Error :", error);
					X.sendMessage(m.chat, {
						text: mess.error
					}, {
						quoted: m
					});
				}
			}
			break;


//━━━━━━━━━━━━━━━━━━━━━━━━//
// Tools Features

			case 'myip':
			case 'ipbot':
				if (!XyrooRynzz) return reply(mess.OnlyOwner);
				let http = require('http');
				http.get({
					'host': 'api.ipify.org',
					'port': 80,
					'path': '/'
				}, function(resp) {
					resp.on('data', function(ip) {
						reply("🔎 Oii, alamat IP publik aku nih: " + ip);
					})
				});
			break;

			case "ipwhois": {
				if (!text) return reply(`*Example :*\n\n${prefix + command} 114.5.213.103`);
				 // wait message
                  reply(global.mess.wait)
				const ip = text.trim();
				const apiUrl = `https://ipwho.is/${ip}`;
				try {
					reply("🔍 Sedang mencari informasi, mohon tunggu...");
					const data = await fetchJson(apiUrl);
					if (data.success) {
						const flagEmoji = data.flag?.emoji || "🏳️";
						let messageText = "📍 *IP Whois Information*\n";
						messageText += `🌐 *IP Address*: ${data.ip}\n`;
						messageText += `🗺️ *Tipe*: ${data.type}\n`;
						messageText += `🌍 *Benua*: ${data.continent} (${data.continent_code})\n`;
						messageText += `🇨🇺 *Negara*: ${data.country} (${data.country_code}) ${flagEmoji}\n`;
						messageText += `🏙️ *Kota*: ${data.city}, ${data.region} (${data.region_code})\n`;
						messageText += `📞 *Kode Panggilan*: +${data.calling_code}\n`;
						messageText += `📫 *Kode Pos*: ${data.postal}\n`;
						messageText += `🏛️ *Ibu Kota*: ${data.capital}\n\n`;
						messageText += "📡 *Provider Informasi*\n";
						messageText += `🏢 *ISP*: ${data.connection?.isp || "Tidak tersedia"}\n`;
						messageText += `🔗 *Domain*: ${data.connection?.domain || "Tidak tersedia"}\n`;
						messageText += `🔢 *ASN*: ${data.connection?.asn || "Tidak tersedia"}\n\n`;
						messageText += "🕰️ *Zona Waktu*\n";
						messageText += `🕒 *ID*: ${data.timezone?.id || "Tidak tersedia"}\n`;
						messageText += `🕒 *UTC*: ${data.timezone?.utc || "Tidak tersedia"}\n`;
						messageText += `🕒 *Waktu Sekarang*: ${data.timezone?.current_time || "Tidak tersedia"}\n`;
						reply(messageText);
					} else {
						reply(`❌ IP Address tidak valid atau informasi tidak ditemukan.`);
					}
				} catch (err) {
					console.error(err);
					reply("❌ Terjadi kesalahan saat mengambil data. Coba lagi nanti.");
				}
			}
			break;
 
case 'telestick': {
  async function telestick(url) {
    let match = url.match(/https:\/\/t\.me\/addstickers\/([^\/\?#]+)/)
    if (!match) return reply(`*Example :*\n\n${prefix + command} https://`);
				 // wait message
                  reply(global.mess.wait)
    let { data: a } = await axios.get(`https://api.telegram.org/bot7935827856:AAGdbLXArulCigWyi6gqR07gi--ZPm7ewhc/getStickerSet?name=${match[1]}`)
    let stickers = await Promise.all(a.result.stickers.map(async v => {
      let { data: b } = await axios.get(`https://api.telegram.org/bot7935827856:AAGdbLXArulCigWyi6gqR07gi--ZPm7ewhc/getFile?file_id=${v.file_id}`)
      return {
        emoji: v.emoji,
        is_animated: v.is_animated,
        image_url: `https://api.telegram.org/file/bot7935827856:AAGdbLXArulCigWyi6gqR07gi--ZPm7ewhc/${b.result.file_path}`
      }
    }))
    return { name: a.result.name, title: a.result.title, sticker_type: a.result.sticker_type, stickers }
  }
 
  try {
    if (!args[0]) return reply('Masukkan url sticker telegram')
    let res = await telestick(args[0])
    for (let v of res.stickers) {
      let { data } = await axios.get(v.image_url, { responseType: 'arraybuffer' })
      let sticker = new Sticker(data, { pack: res.title, author: 'MT-BOT', type: v.is_animated ? 'full' : 'default' })
      await X.sendMessage(m.chat, await sticker.toMessage(), { quoted: m })
    }
  } catch (e) {
    reply(e.message)
  }
}
break;

case 'stikerly': {
if (!text) return reply(`*Example :*\n\n ${prefix + command} anomali `)
				 // wait message
                  reply(global.mess.wait)
try {
const searchRes = await fetch(`https://zenzxz.dpdns.org/search/stickerlysearch?query=${encodeURIComponent(text)}`)
const searchJson = await searchRes.json()
if (!searchJson.status || !Array.isArray(searchJson.data) || searchJson.data.length === 0) {
return reply('*Not Found 🚫*')
}
const pick = searchJson.data[Math.floor(Math.random() * searchJson.data.length)]
const detailUrl = `https://zenzxz.dpdns.org/tools/stickerlydetail?url=${encodeURIComponent(pick.url)}`
const detailRes = await fetch(detailUrl)
const detailJson = await detailRes.json()
if (!detailJson.status || !detailJson.data || !Array.isArray(detailJson.data.stickers) || detailJson.data.stickers.length === 0) {
return reply('error, saat mengambil stiker detal')
}
const packName = detailJson.data.name
const authorName = detailJson.data.author?.name || 'unknown'
reply(`Sending ${detailJson.data.stickers.length} Sticker`)
let maxSend = 10
for (let i = 0; i < Math.min(detailJson.data.stickers.length, maxSend); i++) {
const img = detailJson.data.stickers[i]
let sticker = new Sticker(img.imageUrl, {
pack: packname,
author: author,
type: 'full',
categories: ['Anomali'],
id: 'XyrooRynzz'
})
let buffer = await sticker.toBuffer()
await X.sendMessage(m.chat, { sticker: buffer }, { quoted: m })
}
} catch (e) {
console.error(e)
reply(mess.error)
}
}
break

//━━━━━━━━━━━━━━━━━━━━━━━━//
// Ai Features
case 'quantum-ai':{
  if (!text) return reply(`Contoh:\n${prefix+command} what is artificial intelligence?`)

 // wait message
 reply(global.mess.wait)

  try {
    const api = `https://zelapioffciall.vercel.app/ai/quantum?text=${encodeURIComponent(text)}`
    const res = await fetch(api)
    if (!res.ok) throw await res.text()
    
    const json = await res.json()
    if (!json.result) return reply('❌ Gagal mendapatkan respon dari AI.')

    reply(json.result)
  } catch (e) {
    console.error('[QUANTUM AI ERROR]', e)
    reply('❌ Terjadi kesalahan saat mengambil respon dari Quantum AI.')
  }
}
break
case 'chatai':{
  try {
    if (!args.length) return reply('Masukkan Pertanyaan')    
 // wait message
 reply(global.mess.wait)
    let payload = { messages: [{ role: 'user', content: args.join(' ') }] }
    let headers = { headers: { Origin: 'https://chatai.org', Referer: 'https://chatai.org/' } }
    let { data } = await axios.post('https://chatai.org/api/chat', payload, headers)
    
    reply(data?.content || 'Tidak ada jawaban')
  } catch (e) {
    reply(e.message)
  }
}
break;
case 'conciseai':{
  const chatAI = async text => {
    let user_id = uuidv4().replace(/-/g, '')
    let lastMsg = `USER: ${text}`
    let signature = crypto.createHmac('sha256', 'CONSICESIGAIMOVIESkjkjs32120djwejk2372kjsajs3u293829323dkjd8238293938wweiuwe')
      .update(user_id + lastMsg + 'normal')
      .digest('hex')
 
    let form = new URLSearchParams({
      question: lastMsg,
      conciseaiUserId: user_id,
      signature,
      previousChats: JSON.stringify([{ a: '', b: lastMsg, c: false }]),
      model: 'normal'
    })
 
    let { data } = await axios.post('https://toki-41b08d0904ce.herokuapp.com/api/conciseai/chat', form.toString(), {
      headers: {
        'User-Agent': 'okhttp/4.10.0',
        'Connection': 'Keep-Alive',
        'Accept-Encoding': 'gzip',
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    })
    return data.answer
  }
 
  try {
    if (!args.length) throw 'Masukkan Pertanyaan'
    reply(await chatAI(args.join(' ')))
 // wait message
 reply(global.mess.wait)
  } catch (e) {
    reply(e.message || e)
  }
}
break;
case 'claudeai':{
  if (!text) {
    return reply(`Masukkan Pertanyaan?`)
  }

 // wait message
 reply(global.mess.wait)
 
  try {
    const headers = {
      'Accept': '*/*',
      'Referer': 'https://claudeai.one/',
      'Origin': 'https://claudeai.one',
      'User-Agent': 'Mozilla/5.0'
    }
 
    const res = await fetch('https://claudeai.one/', { headers })
    const html = await res.text()
 
    const dom = new JSDOM(html)
    const doc = dom.window.document
 
    const nonce = doc.querySelector('[data-nonce]')?.getAttribute('data-nonce') || ''
    const postId = doc.querySelector('[data-post-id]')?.getAttribute('data-post-id') || ''
    const botId = doc.querySelector('[data-bot-id]')?.getAttribute('data-bot-id') || ''
 
    const clientId = html.match(/localStorage\.setItem['"]wpaicg_chat_client_id['"],\s*['"](.+?)['"]/)?.[1] || 
      'JHFiony-' + Math.random().toString(36).substring(2, 12)
 
    const form = new FormData()
    form.append('_wpnonce', nonce)
    form.append('post_id', postId)
    form.append('url', 'https://claudeai.one')
    form.append('action', 'wpaicg_chat_shortcode_message')
    form.append('message', text)
    form.append('bot_id', botId)
    form.append('chatbot_identity', 'shortcode')
    form.append('wpaicg_chat_history', '[]')
    form.append('wpaicg_chat_client_id', clientId)
 
    const resPost = await fetch('https://claudeai.one/wp-admin/admin-ajax.php', {
      method: 'POST',
      headers: {
        ...headers,
        ...form.getHeaders()
      },
      body: form
    })
 
    const json = await resPost.json()
    const jawaban = json?.data
 
    if (!jawaban) return reply('[!] Gagal mendapatkan balasan dari Claude.')
 
    await reply(jawaban)
 
  } catch (e) {
    await reply('Terjadi error:\n' + JSON.stringify(e.message || e, null, 2))
  }
 
  break
}
case 'chatgpt':{
    if (!text) return reply(`Masukkan Pertanyaan?`)
    
 // wait message
 reply(global.mess.wait)
     
    const model_list = {
        chatgpt4: {
            api: 'https://stablediffusion.fr/gpt4/predict2',
            referer: 'https://stablediffusion.fr/chatgpt4'
        },
        chatgpt3: {
            api: 'https://stablediffusion.fr/gpt3/predict',
            referer: 'https://stablediffusion.fr/chatgpt3'
        }
    };

    try {
        let results = [];
        for (const [model, config] of Object.entries(model_list)) {
            try {
const axios = require('axios');
                const hmm = await axios.get(config.referer);
                const { data } = await axios.post(config.api, {
                    prompt: text
                }, {
                    headers: {
                        accept: '*/*',
                        'content-type': 'application/json',
                        origin: 'https://stablediffusion.fr',
                        referer: config.referer,
                        cookie: hmm.headers['set-cookie'].join('; '),
                        'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36'
                    }
                });
                results.push(`*${model.toUpperCase()}*:\n${data.message || 'Tidak ada jawaban.'}`);
            } catch (err) {
                results.push(`*${model.toUpperCase()}*:\nGagal mengambil jawaban.`);
                console.error(`Error on ${model}:`, err.message);
            }
        }
        reply(results.join('\n\n'));
    } catch (e) {
        console.error(e);
        reply('Terjadi kesalahan saat mengambil jawaban.');
    }
}
break
case 'venice': case 'veniceai':{
if (!text) return reply(`Masukkan Pertanyaan`);
 // wait message
 reply(global.mess.wait)
try {
const axios = require('axios');
const { data } = await axios.request({
method: 'POST',
url: 'https://outerface.venice.ai/api/inference/chat',
headers: {
accept: '*/*',
'content-type': 'application/json',
origin: 'https://venice.ai',
referer: 'https://venice.ai/',
'user-agent': 'Mozilla/5.0 (Android 10; Mobile; rv:131.0) Gecko/131.0 Firefox/131.0',
'x-venice-version': 'interface@20250523.214528+393d253'
},
data: JSON.stringify({
requestId: 'nekorinn',
modelId: 'dolphin-3.0-mistral-24b',
prompt: [
{
content: text,
role: 'user'
}
],
systemPrompt: '',
conversationType: 'text',
temperature: 0.8,
webEnabled: true,
topP: 0.9,
isCharacter: false,
clientProcessingTime: 15
})
});
const chunks = data.split('\n').filter(v => v).map(v => JSON.parse(v));
const hasil = chunks.map(v => v.content).join('');
X.sendMessage(m.chat, { text: hasil }, { quoted: m });
} catch (e) {
console.error(e.message);
X.sendMessage(m.chat, { text: 'Maaf, tidak ada hasil dari Venice.' }, { quoted: m });
}
}
break
case 'logic-eai':{
    if (!q) {
        return reply(`Mauu Tanyaa Apa`);
    }
 // wait message
 reply(global.mess.wait)
    const customName = "logic-eai"; 
    const creator = "XyrooRynzz";
    const systemMessage = `Nama kamu sekarang adalah ${customName} dan kamu diciptakan oleh ${creator}`;

    const url = "https://velyn.biz.id/api/ai/aicustom";

    try {
        const response = await axios.get(url, {
            params: {
                prompt: q,
                system: systemMessage
            }
        });

        if (response.data && response.data.data) {
            X.sendMessage(m.chat, { text: response.data.data }, { quoted: m });
        } else {
            throw new Error("Tidak ada respon dari API.");
        }
    } catch (error) {
        console.error("Error AI:", error);
        reply("Maaf, terjadi kesalahan saat menghubungi AI.");
    }
};
break
case 'gpt41-mini':{  
const OpenAIPrompt = ``;

const OpenAI = require("openai"); 
const token = "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"; 
const endpoint = "https://models.github.ai/inference";
const model = "openai/gpt-4.1-mini";

async function openai(userPrompt) {
    const client = new OpenAI({
        baseURL: endpoint,
        apiKey: token,
    });

    const response = await X.chat.completions.create({
        messages: [
            { role: "system", content: OpenAIPrompt.trim() }, 
            { role: "user", content: userPrompt }
        ],
        temperature: 1,
        top_p: 1,
        model: model
    });

    return response.choices[0].message.content.replace(/\*\*(.*?)\*\*/g, '*$1*');
}

    if (!text) {
        return reply(`Example: ${prefix+command} Siapa Jokowi`);
    }

 // wait message
 reply(global.mess.wait)    

    try {
        const hasil = await openai(text);
        reply(hasil);
    } catch (e) {
        console.error(e);
        reply('❌ Maaf, Tsukasa-chan sedang kelelahan... coba lagi nanti ya.');
    }
};
break
case 'openai':{  
const OpenAIPrompt = `
hallo ${pushname} Ayo perkenalkan dirimu, saya adalah ${botname} dan Model saya Adalah OpenAI GPT - 4.1 ini, sekaligus saya bukan dep ke orang-orang. Maaf puh
`;

const OpenAI = require("openai"); 
const token = "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"; 
const endpoint = "https://models.github.ai/inference";
const model = "openai/gpt-4.1";


async function openai(userPrompt) {
    const client = new OpenAI({
        baseURL: endpoint,
        apiKey: token,
    });

    const response = await X.chat.completions.create({
        messages: [
            { role: "system", content: OpenAIPrompt.trim() }, 
            { role: "user", content: userPrompt }
        ],
        temperature: 1,
        top_p: 1,
        model: model
    });

    return response.choices[0].message.content.replace(/\*\*(.*?)\*\*/g, '*$1*');
}

    if (!text) {
        return reply(`Example: ${prefix+command} Siapa Penemu Sepak Bola`);
    }

 // wait message
 reply(global.mess.wait)    

    try {
        const hasil = await openai(text);
        reply(hasil);
    } catch (e) {
        console.error(e);
        reply('❌ Maaf, Tsukasa-chan sedang kelelahan... coba lagi nanti ya.');
    }
};
break
case 'metaai':{  
const MetaAi = {
  chat: async (question) => {
    let d = new FormData();
    d.append("content", `User: ${question}`);
    d.append("model", "@groq/llama-3.1-8b-instant");

    let head = {
      headers: {
        ...d.getHeaders(),
      },
    };

    try {
      let { data } = await axios.post("https://mind.hydrooo.web.id/v1/chat", d, head);
      return data.result || data.full_result || JSON.stringify(data);
    } catch (error) {
      console.error("API Error:", error.response?.data || error.message);
      throw new Error("Gagal mengambil jawaban dari AI.");
    }
  }
};


  if (!text) return reply(`Example: ${prefix+command} Siapa Penemu Sepak Bola`);

 // wait message
 reply(global.mess.wait)
 
  try {

    const result = await MetaAi.chat(text);

    await X.sendMessage(m.chat, {
      text: result
    }, { quoted: m });
  } catch (error) {
    console.error("Error:", error);
    await reply("Error :v");
  }
};
break
case 'deepseek':{  

const deepSeekThink = {
  chat: async (question) => {
    let d = new FormData();
    d.append("content", `User: ${question}`);
    d.append("model", "@hf/thebloke/deepseek-coder-6.7b-instruct-awq");

    let head = {
      headers: {
        ...d.getHeaders(),
      },
    };

    try {
      let { data } = await axios.post("https://mind.hydrooo.web.id/v1/chat", d, head);
      return data.result || data.full_result || JSON.stringify(data);
    } catch (error) {
      console.error("API Error:", error.response?.data || error.message);
      throw new Error("Gagal mengambil jawaban dari AI.");
    }
  }
};

  if (!text) return reply(`Example: ${prefix+command} Siapa Jokowi`);

 // wait message
 reply(global.mess.wait)
 
  try {

    const result = await deepSeekThink.chat(text);

    await X.sendMessage(m.chat, {
      text: result
    }, { quoted: m });
  } catch (error) {
    console.error("Error:", error);
    await reply("Error :v");
  }
};
break
case 'gptlogic':{  
    if (!text) return reply(`Example: ${prefix+command} Siapa Jokowi`);
 // wait message
 reply(global.mess.wait)
    try {
        let response = await axios.post("https://chateverywhere.app/api/chat/", {
            "model": {
                "id": "gpt-3.5-turbo-0613",
                "name": "GPT-3.5",
                "maxLength": 12000,
                "tokenLimit": 4000,
                "completionTokenLimit": 2500,
                "deploymentName": "gpt-35"
            },
            "messages": [
                {
                    "pluginId": null,
                    "content": text,
                    "role": "user"
                }
            ],
            "prompt": "Kamu adalah AI yang membantu pengguna dalam menjawab pertanyaan dengan akurat.",
            "temperature": 0.5
        }, {
            headers: {
                "Accept": "/*/",
                "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
            }
        });

        let result = response.data;
        X.sendMessage(m.chat, { text: result }, { quoted: m });
    } catch (error) {
        console.error("Error fetching data:", error);
        X.sendMessage(m.chat, { text: "Terjadi kesalahan saat memproses permintaan." }, { quoted: m });
    }
};
break
case 'aoyoai':{  
  if (!text) return reply('Masukkan pertanyaan?');
 // wait message
 reply(global.mess.wait)
  try {
    let { data } = await axios.get(`https://www.abella.icu/aoyoai?q=${encodeURIComponent(text)}`);
    if (data?.status !== 'success') throw 'Gagal mendapatkan respons dari Web';
    
    let res = data?.data?.response;
    if (!res) throw 'Respons tidak ditemukan';
    
    reply(res);
  } catch (e) {
    reply('Yah Error');
  }
};
break
case 'chatbotai':{  
  if (!text) return reply('Masukkan pertanyaan?');
 // wait message
 reply(global.mess.wait) 
  try {
    let { data } = await axios.get(`https://www.abella.icu/onlinechatbot?q=${encodeURIComponent(text)}`);
    if (data?.data?.answer?.data) {
      reply(data.data.answer.data);
    } else {
      reply('Tidak dapat menemukan jawaban dari AI.');
    }
  } catch (e) {
    reply('Terjadi kesalahan saat mengambil jawaban.');
  }
};
break
case 'blackbox-pro':{  
  if (!text) return reply('Masukkan pertanyaan?');
 // wait message
 reply(global.mess.wait)
  try {
    let { data } = await axios.get('https://www.abella.icu/blackbox-pro?q=' + encodeURIComponent(text));
    if (data?.status !== 'success') return reply('Gagal mengambil jawaban.');
    reply(data.data.answer.result);
  } catch {
    reply('Error');
  }
};
break
case 'zerogpt':
  if (!q) return reply('Masukkan pertanyaan?');
 // wait message
 reply(global.mess.wait)
  try {
    const axios = require('axios');
    const id = () => Math.random().toString(36).slice(2, 18);
    const res = await axios.post('https://zerogptai.org/wp-json/mwai-ui/v1/chats/submit', {
      botId: "default",
      customId: null,
      session: "N/A",
      chatId: id(),
      contextId: 39,
      messages: [],
      newMessage: q,
      newFileId: null,
      stream: true
    }, {
      headers: {
        'Content-Type': 'application/json',
        'X-WP-Nonce': 'e7b64e1953',
        'Accept': 'text/event-stream'
      },
      responseType: 'stream'
    });
    let out = '';
    res.data.on('data', chunk => {
      chunk.toString().split('\n').forEach(line => {
        if (line.startsWith('data: ')) {
          const data = JSON.parse(line.slice(6));
          if (data.type === 'live') out += data.data;
          if (data.type === 'end') reply(out.trim());
        }
      });
    });
  } catch (e) {
    reply('Error: ' + e.message);
  }
  break
case 'writecream':{
 if (!text) return reply(`Masukkan pertanyaan\nExample : ${prefix+command} kamu psikolog|aku sering gelisah malam hari, kenapa ya?`);
 // wait message
 reply(global.mess.wait)
 const [logic, question] = text.split('|').map(v => v.trim());
 if (!logic || !question) return reply(`Format salah\nExample : ${prefix+command} persona|pertanyaan`);
 
 async function writecream(logic, question) {
 const url = "https://8pe3nv3qha.execute-api.us-east-1.amazonaws.com/default/llm_chat";
 const query = [
 { role: "system", content: logic },
 { role: "user", content: question }
 ];
 const params = new URLSearchParams({
 query: JSON.stringify(query),
 link: "writecream.com"
 });

 try {
 const response = await fetch(`${url}?${params.toString()}`);
 const data = await response.json();

 let raw = data.response_content || data.reply || data.result || data.text || '';
 let cleaned = raw
 .replace(/\\n/g, '\n')
 .replace(/\n{2,}/g, '\n\n')
 .replace(/\*\*(.*?)\*\*/g, '*$1*');

 return cleaned.trim();
 } catch (error) {
 return `Gagal mengambil respons: ${error.message}`;
 }
}

 const response = await writecream(logic, question);
 reply(response || 'Tidak ada respons.');
};
break
case 'yupraai':{
if (!text) return reply('Masukkan pertanyaan?');
 // wait message
 reply(global.mess.wait)
 const timestamp = Date.now();
 const sessionId = m.chat;
 const encodedText = encodeURIComponent(text);
 const url = `https://api.yupradev.biz.id/ai/ypai?text=${encodedText}&t=${timestamp}&session=${sessionId}`;

 try {
 const res = await axios.get(url, {
 headers: {
 authority: 'api.yupradev.biz.id',
 accept: '*/*',
 origin: 'https://ai.yupradev.biz.id',
 referer: 'https://ai.yupradev.biz.id/',
 'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36'
 }
 });

 const data = res.data;
 const replyText = data.response || data.result || JSON.stringify(data);
 await reply(replyText.trim(), m);
 } catch (err) {
 console.error(err);
 await reply('❌ Gagal ke API: ${err.message}');
 }
};
break
case 'feloai':{
  if (!q) return reply('Masukkan pertanyaan?');
 // wait message
 reply(global.mess.wait)
  try {

    const licefelo = await Felo(q);
    if (licefelo.error) {
      reply("*Terjadi Kesalahan*");
      return;
    }

    let answer = licefelo.answer || "Tidak ada jawaban yang ditemukan.";
    let sources = licefelo.source.length > 0
      ? `*Sumber Yang Saya Gunakan*:\n${licefelo.source
          .filter(src => src.link)
          .slice(0, 5)
          .map((src, i) => `_${src.link}_`)
          .join("\n\n")}`
      : "-";

    let messg = `ᴘᴏᴡᴇʀᴇᴅ ᴡɪᴛʜ ғᴇʟᴏᴀɪ\n\n${answer}\n\n${sources}`;

    await X.sendMessage(m.chat, { text: messg });
  } catch (error) {
    console.error(error);
    reply("⚠ *Terjadi Kesalahan*");
  }
}
break

case 'aliceai' :{
  try {
    if (!text) return reply(`Tulis sesuatu setelah perintah ini.\n\nContoh:\n${prefix+command} hai apa kabar?\n${prefix+command} https://vt.tiktok.com/ZSFxYcCdr/\n${prefix+command} buatkan gambar wanita`)
 // wait message
 reply(global.mess.wait)
    let regexTikTok = /(https?:\/\/)?(www\.|vm\.|vt\.)?tiktok\.com\/[^\s]+/gi
    let isTikTok = regexTikTok.test(text)
    let isImageReq = /(gambar|buatkan.*gambar|bikin.*gambar|buat.*gambar)/i.test(text)

    if (isTikTok) {
      let link = text.match(regexTikTok)[0]
      let res = await fetch(`https://www.velyn.biz.id/api/downloader/tiktok?url=${encodeURIComponent(link)}`)
      let json = await res.json()

      if (!json?.status || !json?.data?.no_watermark) {
        return reply(`❌ Error\nLogs error : Gagal mengunduh video TikTok.`)
      }

      let prompt = `Buatkan caption menarik untuk video TikTok dengan judul: ${json?.data?.title || 'tanpa judul'}`
      let aiRes = await fetch(`https://www.velyn.biz.id/api/ai/velyn-1.0-1b?prompt=${encodeURIComponent(prompt)}`)
      let aiJson = await aiRes.json()

      if (!aiJson?.status || !aiJson?.result) {
        return reply(`❌ Error\nLogs error : Gagal mendapatkan caption dari AI.`)
      }

      await X.sendMessage(m.chat, {
        video: { url: json.data.no_watermark },
        caption: aiJson.result.toString()
      }, { quoted: m })

    } else if (isImageReq) {
      let prompt = text
      let res = await fetch(`https://www.velyn.biz.id/api/ai/text2img?prompt=${encodeURIComponent(prompt)}`)
      if (!res.ok) return reply(`❌ Error\nLogs error : Gagal menghubungi layanan gambar.`)

      let buffer = await res.buffer()
      await X.sendMessage(m.chat, {
        image: buffer,
        caption: `Berikut hasil gambar untuk prompt:\n*${prompt}*`
      }, { quoted: m })

    } else {
      let prompt = text
      let res = await fetch(`https://www.velyn.biz.id/api/ai/velyn-1.0-1b?prompt=${encodeURIComponent(prompt)}`)
      let json = await res.json()

      if (!json?.status || !json?.result) {
        throw `❌ Error\nLogs error : Gagal merespons pesan AI.`
      }

      reply(json.result.toString())
    }

  } catch (e) {
    console.error(e)
    return reply(`❌ Error\nLogs error : ${(e?.message || e).toString()}`)
  }
}
break

case 'magicstudio':{
    if (!args[0]) return reply(`Masukkan prompt untuk gambar!\nExample: ${prefix+command} buatkan gambar wanita sedang memegang botol cocacola sambil menyender di tembok`);
 // wait message
 reply(global.mess.wait) 
    let prompt = encodeURIComponent(args.join(' '));
    let apiUrl = `https://velyn.biz.id/api/ai/magicStudio?prompt=${prompt}&apikey=velyn`;
 
    try {
        let res = await fetch(apiUrl);
        let contentType = res.headers.get('content-type');
 
        console.log('Content-Type:', contentType); 
 
        if (contentType && contentType.startsWith('image')) {
            let buffer = await res.buffer();
            await X.sendFile(m.chat, buffer, 'magicStudio.jpg', `Berhasil Membuat Gambar\n${packname}`, xy);
        } else {
            reply('Gagal mendapatkan gambar, API mungkin sedang error.');
        }
    } catch (e) {
        console.error('Fetch Error:', e);
        reply('Terjadi kesalahan saat menghubungi API.');
    }
};
break

case 'gemmaai' :{
  if (!text) return reply('Masukkan pertanyaan?');
 // wait message
 reply(global.mess.wait)
  try {
    const res = await fetch(`https://www.velyn.biz.id/api/ai/gemma-2-9b-it?prompt=${encodeURIComponent(text)}`)
    if (res.ok) {
      const json = await res.json()
      if (json.status) {
        await X.sendMessage(m.chat, { text: json.data }, { quoted: m })
      } else {
        await X.sendMessage(m.chat, { text: 'Gagal mendapatkan data dari API.' }, { quoted: m })
      }
    } else {
      await X.sendMessage(m.chat, { text: `Status error: ${res.status}` }, { quoted: m })
    }
  } catch (e) {
    await X.sendMessage(m.chat, { text: 'Terjadi kesalahan internal saat memproses permintaan.' }, { quoted: m })
    console.error(e)
  }
}
break
case 'aivelyn':
case 'velynai':{
  if (!text) return reply('Masukkan pertanyaan?');
 // wait message
 reply(global.mess.wait)
  try {
    const url = `https://www.velyn.biz.id/api/ai/velyn-1.0-1b?prompt=${encodeURIComponent(text)}`;
    const response = await fetch(url);

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    const data = await response.json();
    const result = data.result || "Maaf, tidak ada jawaban.";

    return reply(result);
  } catch (error) {
    console.error("Terjadi kesalahan:", error);
    return reply("Maaf, terjadi kesalahan saat menghubungi AI.");
  }
}
break

case 'muslimai':{
  if (!text) return reply('Masukkan pertanyaan?');
 // wait message
 reply(global.mess.wait)
  try {
    const result = await muslimai(text);

    if (result.error) return reply(result.error);

    let sourcesText = result.sources.length > 0 
        ? result.sources.map((src, index) => `${index + 1}. *${src.title}*\n🔗 ${src.url}`).join("\n\n")
        : "Tidak ada sumber yang ditemukan.";

    let responseMessage = `ᴘᴏᴡᴇʀᴇᴅ ᴡɪᴛʜ ᴍᴜsʟɪᴍᴀɪ\n\n${result.answer}`;

    reply(responseMessage);
} catch (error) {
    console.error("⚠ *Error* :", error);
    reply("Terjadi kesalahan.");
}
}
break;

case 'llama-ai':{
let messages = [];
  try {
 
    if (!text) return reply('Masukkan pertanyaan?');
    let response = await fetch(`https://restapii.rioooxdzz.web.id/api/llama?message=${encodeURIComponent(text)}`);
 // wait message
 reply(global.mess.wait) 
    if (!response.ok) {
      throw new Error("Request to OpenAI API failed");
    }
 
    let result = await response.json();
 
    await X.sendMessage(m.chat, {
      text: "" + result.data.response,
    });
 
    messages = [...messages, { role: "user", content: text }];
  } catch (error) {
    await X.sendMessage(m.chat, {
      text: "" + `Error: ${error.message}`,
    });
  }
}
break

case 'gptturbo':{
async function gptturbo(query) {
    const apiUrl = `https://restapii.rioooxdzz.web.id/api/gptturbo?message=${encodeURIComponent(query)}`;
 
    try {
        const response = await fetch(apiUrl, {
            method: 'GET',
            headers: {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36",
            }
        });
        if (!response.ok) {
            throw new Error(`Error: ${response.status}`);
        }
 
        const responseJson = await response.json();
         if (responseJson && responseJson.data.response) {
            return responseJson.data.response;
        } else {
            return "Tidak ada pesan dalam response.";
        }
    } catch (error) {
        console.error("Terjadi kesalahan:", error.message);
        return "Gagal mendapatkan respons dari server.";
    }
}
 
if (!text) return reply(`Contoh:\n${Xyroo}${command} Halo?`);
 // wait message
 reply(global.mess.wait)
let gpiti = await gptturbo(text);
let turbo = `Title : ${text}\n\nMessage : ${gpiti}\n`;
await X.sendMessage(m.chat, {
    text: "⬣───「 *G P T T U R B O* 」───⬣" + "\n\n" + turbo,
    contextInfo: {
      externalAdreply: {  
        title: "GPT - TURBO",
        body: '',
        thumbnailUrl: "https://pomf2.lain.la/f/jzv6iqu.jpg",
        sourceUrl: null,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  }, { quoted: m });
}
break

case 'gemini-ai':{  
    const isQuotedImage = m.quoted && m.quoted.mtype === 'imageMessage';
    const isImage = m.mtype === 'imageMessage';
    const quoted = m.quoted ? m.quoted : m;

    if (isImage || isQuotedImage) {
        try {

            const mediaPath = await X.downloadAndSaveMediaMessage(quoted);
            const media = fs.readFileSync(mediaPath);

            const uploadedImageUrl = await uploadImage(media);
            console.log('Gambar berhasil diupload:', uploadedImageUrl);

            const apiUrl = `https://gemini-api-5k0h.onrender.com/gemini/image`;
            const params = {
                q: 'What is this picture? Please describe it.',
                url: uploadedImageUrl
            };

            const response = await axios.get(apiUrl, { params });
            const description = response.data?.content || 'Gagal mendapatkan deskripsi gambar.';

            await X.sendMessage(m.chat, {
                text: `📷 *Deskripsi Gambar:*\n${description}`
            }, { quoted: m });

            fs.unlinkSync(mediaPath);
        } catch (error) {
            console.error('Error deskripsi gambar:', error);
            await X.sendMessage(m.chat, {
                text: '❌ Terjadi kesalahan saat memproses gambar.'
            }, { quoted: m });
        }
    } else {
        try {
            if (!text) return reply(`Example: ${prefix+command} Siapa Jokowi`);
 // wait message
 reply(global.mess.wait)
            const apiUrl = `https://gemini-api-5k0h.onrender.com/gemini/chat`;
            const params = { q: text };

            const response = await axios.get(apiUrl, { params });
            const replyText = response.data?.content || 'Gagal mendapatkan respons AI.';

            await X.sendMessage(m.chat, {
                text: `🤖 *AI Gemini:*\n${replyText}`
            }, { quoted: m });
        } catch (error) {
            console.error('Error Gemini Chat:', error);
            await X.sendMessage(m.chat, {
                text: '❌ Terjadi kesalahan saat memproses permintaan AI.'
            }, { quoted: m });
        }
    }
};
break

case 'lumin-ai':{
  if (!q) return reply(`Ada yang bisa aku bantu?`);
 // wait message
 reply(global.mess.wait)  
  try {
      const aliceeai = await Eai(q);
      if (!aliceeai) {
          return reply("Tidak Ada Respon");
      }
      await reply(`${aliceeai}\n\n${packname}`);
  } catch (error) {
      console.error("Error Saat Mendapatkan Data :", error.message);
      reply("Terjadi Kesalahan Dalam Proses Permintaan.");
  }
}
break

case 'typli-ai':{
 if (!q) return reply(`_Tanya apa?_`);
 // wait message
 reply(global.mess.wait) 
 // wm avz
 const avz = async (prompt) => {
   const data = {
     prompt: prompt,
     temperature: 1.2
   };
// wm avz
   const config = {
     method: 'post',
     url: 'https://typli.ai/api/generators/completion',
     headers: {
       'Content-Type': 'application/json',
       'Accept': 'application/json'
     },
     data: JSON.stringify(data)
   };
// wm avz
   try {
     const response = await axios(config);
     return response.data;
   } catch (error) {
     console.error("Fetch error:", error.response ? error.response.data : error.message);
     throw error;
   }
 };
 // wm avz
 const avoskybaik = `${encodeURIComponent(q)}`;
 try {
   const answer = await avz(q);
   reply(answer);
 } catch (error) {
   reply("Terjadi kesalaha!");
 }
}
break;

case 'poly-ai':{
  if (!q) return reply(`_Tanya apa?_`);
 // wait message
 reply(global.mess.wait)
  async function polybuzzAi(prompt) {
  let data = new URLSearchParams();
  data.append('currentChatStyleId', '1');
  data.append('mediaType', '2');
  data.append('needLive2D', '2');
  data.append('secretSceneId', 'wHp7z');
  data.append('selectId', '209837277');
  data.append('speechText', prompt);

  let headers = {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
    'Cookie': 'session=9997156d23496b9ff96fc09d162191f74821790eaa4ecc52096273a60f517ad3',
  };

  try {
    let { data: respon } = await axios.post('https://api.polybuzz.ai/api/conversation/msgbystream', data, { headers });
    //dibantu ama ai paling sigma(ChatGpt) kode kemaren yg cvbee.ai
    const result = respon.split('\n')
      .filter(line => line.trim())
      .map(line => {
        try {
          const json = JSON.parse(line.trim());
          return json.content || '';
        } catch (e) {
          console.error("Invalid JSON:", line);
          return '';
        }
      })
      .join('');
      //
    return result;
  } catch (e) {
    console.error(e);
    return null;
  }
}
 try {
   const answer = await polybuzzAi(q);
   reply(answer);
 } catch (error) {
   reply("Terjadi kesalahan !");
 }
}
 break
 

case 'chatevery-where':{
  if (!text) return reply(`Example: ${prefix+command} axios`)
 // wait message
 reply(global.mess.wait)
async function xyy(prompt) {
  const response = await axios({
    method: "POST",
    url: "https://chateverywhere.app/api/chat",
    headers: {
      "Content-Type": "application/json",
      "Cookie": "_ga=GA1.1.34196701.1707462626; _ga_ZYMW9SZKVK=GS1.1.1707462625.1.0.1707462625.60.0.0; ph_phc_9n85Ky3ZOEwVZlg68f8bI3jnOJkaV8oVGGJcoKfXyn1_posthog=%7B%22distinct_id%22%3A%225aa4878d-a9b6-40fb-8345-3d686d655483%22%2C%22%24sesid%22%3A%5B1707462733662%2C%22018d8cb4-0217-79f9-99ac-b77f18f82ac8%22%2C1707462623766%5D%7D",
      Origin: "https://chateverywhere.app",
      Referer: "https://chateverywhere.app/id",
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36"
    },
    data: {
      model: {
        id: "gpt-3.5-turbo-0613",
        name: "GPT-3.5",
        maxLength: 12000,
        tokenLimit: 4000,
      },
      prompt: prompt,
      messages: [{
        pluginId: null,
        content: prompt,
        role: "user"
      },
        {
          pluginId: null,
          content: `${botname} adalah programmer yang berasal dari Sumatera Selatan, Indonesia. Ia adalah seorang yang mengembangkan semua aplikasi.`,
          role: "assistant"
        }]
    }
  })

  return response.data
}
try {
let jut = await xyy(text)
reply(`${jut}`)
} catch (error) {
  reply(error.message)
}
}
break

case 'gemini-pro':{
  if (!text) return reply(`Contoh:\n${prefix+command} Apa itu chatgpt`);
 // wait message
 reply(global.mess.wait)
async function fetchWithModel(content, model, token) {
    try {
      const response = await axios.post('https://luminai.my.id/', {
        content,
        model,
        headers: {
                'Authorization': `Bearer ${token}`
                 }
      });

      console.log(response.data);
      return response.data;
    } catch (error) {
      console.error(error);
      throw error;
    }
  }
  fetchWithModel(text, 'gemini-pro', '8be9e34764cd2fc4e6bcfb1bf6a945efe30406573a92d8ef0ec1613dc0e54876')
    .then(data => {
      const textl = data.result;
      reply(textl);
    })
  break;
}
  
case 'gpt-4o':{
  if (!text) return reply(`Contoh:\n${Xyroo}${command} Apa itu chatgpt`);
 // wait message
 reply(global.mess.wait)
  async function fetchWithModel(content, model, token) {
    try {
      const response = await axios.post('https://luminai.my.id/', {
        content,
        model,
        headers: {
                'Authorization': `Bearer ${token}`
                 }
      });

      console.log(response.data);
      return response.data;
    } catch (error) {
      console.error(error);
      throw error;
    }
  }

  fetchWithModel(text, 'gpt-4o', '8be9e34764cd2fc4e6bcfb1bf6a945efe30406573a92d8ef0ec1613dc0e54876')
    .then(data => {
      const textl = data.result;
      reply(textl);
    })
    .catch(error => console.error(error));
  break;
}
 
case 'ai':{
  if (!text) {
    return reply(`mau tanya apa?`);
  }
 // wait message
 reply(global.mess.wait)
  const prompt = `Anda adalah ai, kamu memiliki kecerdasan ai yang luar biasa, kamu senang membantu orang lain, dan gaya bicara mu sangatlah sopan`
  const requestData = { content: text, user: m.sender, prompt: prompt };
  const quoted = m && (m.quoted || m);

  try {
    let response;
    const mimetype = quoted?.mimetype || quoted?.msg?.mimetype;

    if (mimetype && /image/.test(mimetype)) {
      requestData.imageBuffer = await quoted.download();
    }

    response = (await axios.post('https://luminai.my.id', requestData)).data.result;
    reply(response);
  } catch (err) {
    reply(err.toString());
  }
}
                break
                
//━━━━━━━━━━━━━━━━━━━━━━━━//
// Game Features
case 'tebakld': {
  let leaderboard = loadLeaderboard();

  // Ubah jadi array dan urutkan berdasar score desc
  let sorted = Object.entries(leaderboard)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10); // Top 10
 
  if (sorted.length === 0) return reply('📊 Leaderboard masih kosong.');

  let teks = '📊 *Leaderboard Tebak-Tebakan*\n\n';
  let rank = 1;
  for (let [userId, score] of sorted) {
    teks += `${rank}. @${userId.split('@')[0]} - ${score} poin\n`;
    rank++;
  }

  return reply(teks, { mentions: sorted.map(([u]) => u) });
}
break;
case 'tebak': {
  const quizPath = './database/tebakgame.json';
  if (!fs.existsSync(quizPath)) return reply('⚠️ File .json tidak ditemukan.');

  const data = JSON.parse(fs.readFileSync(quizPath));
  const kategoriUnik = [...new Set(data.map(item => item.kategori))];

  const kategori = args[0]?.toLowerCase();
  if (!kategori) {
    const daftar = kategoriUnik.join(', ');
    return reply(`📚 Gunakan: .tebak [kategori]\nContoh: .tebak lagu\n\nKategori yang tersedia:\n${daftar}`);
  }

  if (!kategoriUnik.includes(kategori)) {
    return reply(`❌ Kategori "${kategori}" tidak ditemukan.\nKategori yang tersedia: ${kategoriUnik.join(', ')}`);
  }
// wait message
reply(global.mess.wait)
  const soalKategori = data.filter(item => item.kategori === kategori);
  const soal = soalKategori[Math.floor(Math.random() * soalKategori.length)];

  if (!global.tebakGame) global.tebakGame = {};
  if (global.tebakGame[m.sender]) {
    return reply('⚠️ Kamu masih punya soal yang belum dijawab atau belum nyerah!');
  }

  global.tebakGame[m.sender] = {
    jawaban: soal.jawaban,
    soal: soal.soal,
    petunjuk: soal.petunjuk || 'Petunjuk tidak tersedia',
    timeout: setTimeout(() => {
      if (global.tebakGame[m.sender]) {
        reply(`⏰ Waktu habis!\nJawaban yang benar:\n✅ *${global.tebakGame[m.sender].jawaban}*`);
        delete global.tebakGame[m.sender];
      }
    }, 60000) // 60 detik
  };

  return reply(`🧠 Tebak kategori *${kategori}* dari petunjuk ini:\n\n${soal.soal}\n\n⏳ Waktu menjawab: *60 detik*\n\n📌 *Reply pesan ini untuk menjawab!*`);
}
break;
//━━━━━━━━━━━━━━━━━━━━━━━━//
//━━━━━━━━━━━━━━━━━━━━━━━━//
// Info Bot		
case 'ping':
case 'info':
case 'storage':
case 'server':
case 'srvinfo': {

  function formatp(bytes) {
    if (bytes < 1024) return `${bytes} B`
    const kb = bytes / 1024
    if (kb < 1024) return `${kb.toFixed(2)} KB`
    const mb = kb / 1024
    if (mb < 1024) return `${mb.toFixed(2)} MB`
    const gb = mb / 1024
    return `${gb.toFixed(2)} GB`
  }

async function getServerInfo() {
  try {
    const start = Date.now()

    const osType = nou.os.type()
    const release = os.release()
    const arch = os.arch()
    const nodeVersion = process.version
    const ip = await nou.os.ip()

    const cpus = os.cpus()
    const cpuModel = cpus[0].model
    const coreCount = cpus.length
    const cpu = cpus.reduce((acc, cpu) => {
      acc.total += Object.values(cpu.times).reduce((a, b) => a + b, 0)
      acc.speed += cpu.speed
      acc.times.user += cpu.times.user
      acc.times.nice += cpu.times.nice
      acc.times.sys += cpu.times.sys
      acc.times.idle += cpu.times.idle
      acc.times.irq += cpu.times.irq
      return acc
    }, { speed: 0, total: 0, times: { user: 0, nice: 0, sys: 0, idle: 0, irq: 0 } })
    const cpuUsage = ((cpu.times.user + cpu.times.sys) / cpu.total * 100).toFixed(2) + '%'
    const loadAverage = os.loadavg()
    const totalMem = os.totalmem()
    const freeMem = os.freemem()
    const usedMem = totalMem - freeMem
    const storageInfo = await nou.drive.info()
    const latensi = (Date.now() - start) / 1000  // Latency yang benar!

    const responseText = `
INFO SERVER
• OS: ${osType} (${release})
• Arsitektur: ${arch}
• Versi Node.js: ${nodeVersion}

CPU SISTEM
• Model: ${cpuModel}
• Kecepatan: ${cpu.speed} MHz
• Beban CPU: ${cpuUsage} (${coreCount} Core)
• Load Average: ${loadAverage.join(', ')}

MEMORI (RAM)
• Total: ${formatp(totalMem)}
• Digunakan: ${formatp(usedMem)}
• Tersedia: ${formatp(freeMem)}

PENYIMPANAN
• Total: ${storageInfo.totalGb} GB
• Digunakan: ${storageInfo.usedGb} GB (${storageInfo.usedPercentage}%)
• Tersedia: ${storageInfo.freeGb} GB (${storageInfo.freePercentage}%)

PING
• Latensi: ${latensi.toFixed(4)} detik
• Uptime Vps: ${runtime(os.uptime())}
`
    return responseText.trim()
  } catch (error) {
    console.error('Error mendapatkan informasi server:', error)
    return 'Terjadi kesalahan dalam mendapatkan informasi server.'
  }
}

const responseText = await getServerInfo()
await X.sendMessage(m.chat, { text: responseText }, { quoted: m })
}
break		

case 'totalfitur':{
reply(`Total Fitur Bot : ${totalfitur()}`)
}
break	
//━━━━━━━━━━━━━━━━━━━━━━━━//
default:
if (budy.startsWith('=>')) {
if (!XyrooRynzz) return
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)
}
return reply(bang)
}
try {
reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
reply(String(e))
}
}

if (budy.startsWith('>')) {
if (!XyrooRynzz) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await reply(require('util').format(teks))
}
}

if (budy.startsWith('$')) {
if (!XyrooRynzz) return
exec(budy.slice(2), (err, stdout) => {
if (err) return reply(`${err}`)
if (stdout) return reply(stdout)
})
}
}

} catch (err) {
  let error = err.stack || err.message || util.format(err);
  console.log('====== ERROR REPORT ======');
  console.log(error);
  console.log('==========================');

  await X.sendMessage(`${owner}@s.whatsapp.net`, {
    text: `⚠️ *LAPORAN ERROR!*\n\n📌 *Message:* ${err.message || '-'}\n📂 *Stack Trace:*\n${error}`,
    contextInfo: { forwardingScore: 9999999, isForwarded: true }
  }, { quoted: m });
}
}
//━━━━━━━━━━━━━━━━━━━━━━━━//
// File Update
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Uodate File 📁 : ${__filename}`)
delete require.cache[file]
require(file)
})