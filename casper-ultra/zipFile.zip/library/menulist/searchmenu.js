const searchMenu = `
╭───⊷ 🔍 Search Features
│ • wikimedia
│ • mangainfo
│ • mangadetail
│ • jkt48news
│ • otakudesu
│ • kusonimeinfo
│ • kusonimesearch
│ • infogempa
╰─────────────
`
module.exports = searchMenu