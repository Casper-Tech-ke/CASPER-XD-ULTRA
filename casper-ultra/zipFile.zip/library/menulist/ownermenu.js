const ownerMenu = `
╭───⊷ 👑 Developer Tools
│ • >
│ • $
│ • =>
│ • Self
│ • Public
│ • Restart
│ • Addplugin
│ • Rmplugin
│ • Cgplugin
│ • Getplugin
╰─────────────
`
module.exports = ownerMenu